
from similarPaint2 import PaintApp

class Main():
    def main():
        
        app = PaintApp()
    main()
 