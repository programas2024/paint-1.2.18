import tkinter as tk
from Tooltip import Tooltip

class Plantillas:
    def __init__(self, root, paint_app):
        self.root = root
        self.paint_app = paint_app
        self.root.title("Plantillas")
        self.root.geometry("2000x700")

        # Crear un canvas blanco que cubra toda la interfaz
        self.canvas = tk.Canvas(root, bg='white', width=2000, height=700)
        self.canvas.place(x=0, y=0)

        # Label para mostrar el tipo de plantilla
        label = tk.Label(root, text="Tipo de Plantilla", bg='white')
        label.place(x=10, y=30)

       

        # Cargar las imágenes
        self.imagen10 = tk.PhotoImage(file="paint/imagenes/planilla11.png")
        self.imagen11 = tk.PhotoImage(file="paint/imagenes/plantilla222.png")
        self.imagen12 = tk.PhotoImage(file="paint/imagenes/plantilla333.png")
        self.imagen13 = tk.PhotoImage(file="paint/imagenes/plantilla44.png")
        self.imagen14 = tk.PhotoImage(file="paint/imagenes/plantilla55.png")

        # Etiquetas para los botones de plantilla
        label_template1 = tk.Label(root, text="Plantilla 1", bg='white')
        label_template1.place(x=20, y=100)

        label_template2 = tk.Label(root, text="Plantilla 2", bg='white')
        label_template2.place(x=370, y=100)

        label_template3 = tk.Label(root, text="Plantilla 3", bg='white')
        label_template3.place(x=700, y=100)

        label_template4 = tk.Label(root, text="Plantilla 4", bg='white')
        label_template4.place(x=1025, y=100)

        label_template4 = tk.Label(root, text="Plantilla 5", bg='white')
        label_template4.place(x=20, y=380)

        # Botones para cada plantilla
        button_template1 = tk.Button(root, text="Plantilla 1", image=self.imagen10, command=lambda: self.set_background("paint/imagenes/planilla1.png"))
        button_template1.place(x=20, y=130)
        Tooltip(button_template1,"Ahora de la pintura el poder en tu mano")

        button_template2 = tk.Button(root, text="Plantilla 2", image=self.imagen11, command=lambda: self.set_background("paint/imagenes/plantilla22.png"))
        button_template2.place(x=370, y=130)
        Tooltip(button_template2,"Marca dinamica como tu arte")

        button_template3 = tk.Button(root, text="Plantilla 3", image=self.imagen12, command=lambda: self.set_background("paint/imagenes/plantilla33.png"))
        button_template3.place(x=700, y=130)
        Tooltip(button_template3,"Paleta y brocha lo que necesitas,para tu potencial")

        button_template4 = tk.Button(root, text="Plantilla 4", image=self.imagen13, command=lambda: self.set_background("paint/imagenes/plantilla444.png"))
        button_template4.place(x=20, y=400)
        
        
        Tooltip(button_template4,"Tropical para tus bonitos dias")
        button_template5 = tk.Button(root, text="Plantilla 5", image=self.imagen14, command=lambda: self.set_background("paint/imagenes/plantilla555.png"))
        button_template5.place(x=1025, y=130)
       
        
        Tooltip(button_template5,"Colores para vivir tu mundo")
       

    def set_background(self, image_path):
        # Establecer la imagen como fondo del lienzo en la clase PaintApp
        self.paint_app.set_background_image(image_path)
        self.close_window()

    def close_window(self):
        # Cerrar la ventana de plantillas
        self.root.destroy()
