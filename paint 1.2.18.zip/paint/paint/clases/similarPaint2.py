import tkinter as tk
from tkinter import *
from tkinter import filedialog, colorchooser, ttk
from PIL import Image, ImageTk, ImageDraw
from PIL import ImageGrab
from Plantillas import Plantillas
from Compartir import Compartir
import pyperclip
from tkinter import font
from Tamanaño import Tamaño
from Tooltip import Tooltip
from Version import version
from Ayuda1 import ayuida1
from Atajos import Atajos
import time
class PaintApp:
    def __init__(self):
        self.root = Tk()
        self.root.title("Paint App")
        self.root.geometry("2000x700")
        self.root.config(bg='white')

        self.canvas = tk.Canvas(self.root, bg='white', width=2000, height=640,background="white")
        self.canvas.place(x=0, y=63, width=2000, height=640)

        self.create_widgets()
        self.bind_events()

        self.custom_brush_size_frame = None  
        self.pincel_menu = None
        self.current_tool = None
        self.pincel_size = 1
        self.last_x, self.last_y = None, None
        self.image_labels = []  # Lista para almacenar todas las etiquetas de imágenes
        self.image_positions = []  # Lista para almacenar las posiciones de las imágenes
        self.image_originals = {}  # Diccionario para almacenar las imágenes originales de PIL
        self.drag_data = {"item": None, "x": 0, "y": 0}
        self.image_dragging = False
        self.selected_color = None
        self.background_image = None
        self.selected_shape_color = "white"
        self.update_time()
        #instacias
        self.compartir = Compartir(self)
        self.tamaño = Tamaño(self.root, self.set_pincel_size)
       #
        # Variables para texto
        self.text_font = tk.StringVar(value="Arial")
        self.text_size = tk.IntVar(value=12)
        self.text_color = tk.StringVar(value="black")

        self.create_text_options()
        self.root.mainloop()

    def create_widgets(self):


        self.imagen1 = tk.PhotoImage(file="paint/imagenes/portalapiz.png")
        self.imagen2 = tk.PhotoImage(file="paint/imagenes/formas.png")
        self.imagen3 = tk.PhotoImage(file="paint/imagenes/borrador.png")
        self.imagen4 = tk.PhotoImage(file="paint/imagenes/letras.png")
        self.imagen5 = tk.PhotoImage(file="paint/imagenes/paleta-de-color.png")
        self.imagen6 = tk.PhotoImage(file="paint/imagenes/imagensubida.png")
        self.imagen7 = tk.PhotoImage(file="paint/imagenes/descargarbajada.png")
        self.imagen8 = tk.PhotoImage(file="paint/imagenes/borrar.png")
        self.imagen9 = tk.PhotoImage(file="paint/imagenes/tema.png")
        self.imagen10 = tk.PhotoImage(file="paint/imagenes/compartir.png")
        self.imagen11 = tk.PhotoImage(file="paint/imagenes/pincel delgado.png")
        self.imagen12 = tk.PhotoImage(file="paint/imagenes/pincel medio.png")
        self.imagen13 = tk.PhotoImage(file="paint/imagenes/pincel gruezo.png")
        self.imagen14 = tk.PhotoImage(file="paint/imagenes/cuadrado.png")
        self.imagen15 = tk.PhotoImage(file="paint/imagenes/circulo.png")
        self.imagen16 = tk.PhotoImage(file="paint/imagenes/linea.png")
        self.imagen17 = tk.PhotoImage(file="paint/imagenes/triangulo.png")
        self.imagen18 = tk.PhotoImage(file="paint/imagenes/borrador bebe.png")
        self.imagen19 = tk.PhotoImage(file="paint/imagenes/borrador mediano.png")
        self.imagen20 = tk.PhotoImage(file="paint/imagenes/borrador grande.png")
        self.imagen21 = tk.PhotoImage(file="paint/imagenes/whatsapp (1).png")
        self.imagen22 = tk.PhotoImage(file="paint/imagenes/facebook.png")
        self.imagen23 = tk.PhotoImage(file="paint/imagenes/instagram.png")
        self.imagen24 = tk.PhotoImage(file="paint/imagenes/cepillo (1).png")
        self.imagen25 = tk.PhotoImage(file="paint/imagenes/version.png")
        self.imagen27 = tk.PhotoImage(file="paint/imagenes/pregunta (1).png")
        self.imagen28 = tk.PhotoImage(file="paint/imagenes/aplicacion-de-secuencia-de-comandos-de-acceso-directo (1).png")

        # Crear botones
        self.pincel_button = tk.Button(self.root, text="Pincel",cursor="hand2",image=self.imagen1, command=self.create_pincel_menu,border=0,background="white")
        Tooltip(self.pincel_button,"Pinceles")
        self.formas_button = tk.Button(self.root, text="Formas",cursor="hand2",image=self.imagen2,border=0,background="white", command=self.create_formas_menu)
        Tooltip(self.formas_button,"Formas")
        self.borrador_button = tk.Button(self.root, text="Borrador",cursor="hand2",image=self.imagen3,background="white",border=0, command=self.create_borrador_menu)
        Tooltip(self.borrador_button,"borrador")
        self.texto_button = tk.Button(self.root, text="Texto",cursor="hand2", image=self.imagen4,background="white",border=0,command=self.select_text_tool)
        Tooltip(self.texto_button,"Texto")
        self.palette_button = tk.Button(self.root, text="Paleta",cursor="hand2",image=self.imagen5,border=0,background="white", command=self.open_color_palette)
        Tooltip(self.palette_button,"Paleta de colores")
        self.import_button = tk.Button(self.root, text="Importar",cursor="hand2",image=self.imagen6,border=0,background="white", command=self.import_image)
        Tooltip(self.import_button,"Importar imagen")
        self.export_button = tk.Button(self.root, text="Exportar",cursor="hand2",image=self.imagen7,background="white",border=0, command=self.export_image)
        Tooltip(self.export_button,"Exportar imagen")
        self.delete_images_button = tk.Button(self.root, text="Eliminar Imágenes",cursor="hand2",image=self.imagen8,background="white",border=0, command=self.delete_all_images)
        Tooltip(self.delete_images_button,"Eliminar imagen")
        self.plantilla_button = tk.Button(self.root, text="Plantilla",cursor="hand2",image=self.imagen9,border=0,background="white", command=self.open_template_window)  # Nuevo botón
        Tooltip(self.plantilla_button,"Plantillas de fondo ")
        self.compartir_button = tk.Button(self.root, text="Compartir",cursor="hand2",image=self.imagen10,border=0,background="white", command=self.display_share_menu)
        Tooltip(self.compartir_button,"Compartir")
        
        self.color_menu_button = tk.Button(self.root, text="Colores",cursor="hand2",image=self.imagen24,background="white",border=0, command=self.create_color_menu)
        self.color_menu_button.place(x=1050,y=13)
        Tooltip(self.color_menu_button,"Colores de pincel rapidos")

        self.version = tk.Button(self.root, text="version",cursor="hand2",image=self.imagen25,background="white",border=0, command=self.mostrar_version)
        Tooltip(self.version,"Version")
        self.version.place(x=1095,y=10)

        self.ayuda = tk.Button(self.root, text="Ayuda",cursor="hand2",image=self.imagen27,background="white",border=0, command=self.mostrar_ayuda)
        Tooltip(self.ayuda,"Ayuda")
        self.ayuda.place(x=1148,y=13)

        self.ayuda = tk.Button(self.root, text="Atajos",cursor="hand2",image=self.imagen28,background="white",border=0, command=self.mostrar_atajos)
        Tooltip(self.ayuda,"Atajos")
        self.ayuda.place(x=1195,y=13)

        self.time_label = tk.Label(self.root, text="", bg='white')
        self.time_label.place(x=1233, y=10)

        # Label para mostrar el día y el año
        self.date_label = tk.Label(self.root, text="", bg='white')
        self.date_label.place(x=1233, y=30)



        # Ubicar los botones usando place
        self.pincel_button.place(x=10, y=10)
        self.formas_button.place(x=80, y=10)
        self.borrador_button.place(x=150, y=10)
        self.texto_button.place(x=220, y=10)
        self.palette_button.place(x=290, y=10)
        self.import_button.place(x=360, y=10)
        self.export_button.place(x=430, y=10)
        self.delete_images_button.place(x=500, y=10)
        self.plantilla_button.place(x=800, y=10)  # Posición del nuevo botón
        self.compartir_button.place(x=870, y=10)

        # Crear separador horizontal
        separator = tk.Frame(self.root, height=2, bd=1, relief=tk.SUNKEN, bg='black')
        separator.place(x=0, y=63, width=2000)

       #formato imagen 
       # Crear una fuente cursiva
        self.cursive_font = font.Font(family="Arial", size=10, slant="italic")
        # Crear una fuente "Cascadia Mono" para el botón "Cuadrado"
        self.cascadia_font = font.Font(family="Cascadia Mono", size=10)


    def bind_events(self):
        self.canvas.bind('<B1-Motion>', self.paint)
        self.canvas.bind('<ButtonRelease-1>', self.reset_last_pos)
        self.canvas.bind('<Button-3>', self.start_shape)
        self.canvas.bind('<B3-Motion>', self.draw_shape)
        self.canvas.bind('<ButtonRelease-3>', self.end_shape)
        self.canvas.bind('<Button-2>', self.handle_click)
        self.canvas.bind('<Button-1>', self.eliminar_foto)
        self.canvas.bind('<Double-Button-1>', self.display_paste_menu)
        self.canvas.bind('<Double-Button-3>', self.fill_shape)
        
    def display_share_menu(self):
        menu = tk.Menu(self.root, tearoff=0,background="white",border=0)
        menu.add_command(label="Compartir en WhatsApp",image=self.imagen21,compound="left", command=self.compartir.share_on_whatsapp)
        menu.add_command(label="Compartir en Facebook",image=self.imagen22,compound="left", command=self.compartir.share_on_facebook)
        menu.add_command(label="Compartir en Instagram",image=self.imagen23,compound="left", command=self.compartir.share_on_instagram)
        menu.post(870, 100)  # Ajusta las coordenadas según tu preferencia

    def create_pincel_menu(self):
        menu = tk.Menu(self.root, tearoff=0,background="white")
        menu.add_command(label="Pincel Delgado",image=self.imagen11,compound="left" ,font=self.cursive_font, command=lambda: self.set_pincel_size(2))
        menu.add_command(label="Pincel Mediano",image=self.imagen12,compound="left",font=self.cursive_font, command=lambda: self.set_pincel_size(5))
        menu.add_command(label="Pincel Grueso",image=self.imagen13,compound="left",font=self.cursive_font, command=lambda: self.set_pincel_size(10))
        menu.add_command(label="Personalizar Tamaño", command=lambda: self.tamaño.show_custom_brush_size_slider())
        menu.post(10,100)
        self.pincel_menu = menu

    

    def create_formas_menu(self):
        menu = tk.Menu(self.root, tearoff=0,background="white",borderwidth=0)
        menu.add_command(label="  Cuadrado",image=self.imagen14,background="white",font=self.cascadia_font,compound="left", command=lambda: self.select_tool('cuadrado'))
        menu.add_command(label="  Círculo",image=self.imagen15,compound="left" ,font=self.cascadia_font,command=lambda: self.select_tool('circulo'))
        menu.add_command(label="  Línea", image=self.imagen16,compound="left",font=self.cascadia_font,command=lambda: self.select_tool('linea'))
        menu.add_command(label="  Triángulo",image=self.imagen17, compound="left",font=self.cascadia_font,command=lambda: self.select_tool('triangulo'))
       

        menu.post(80, 100)  # Ubicar el menú desplegable justo debajo del botón

    def create_borrador_menu(self):
        menu = tk.Menu(self.root, tearoff=0,background="white",border=0)
        menu.add_command(label="Borrador Pequeño",image=self.imagen18,compound="left", command=lambda: self.set_borrador_size(6))
        menu.add_command(label="Borrador Mediano",image=self.imagen19,compound="left" ,command=lambda: self.set_borrador_size(15))
        menu.add_command(label="Borrador Grande",image=self.imagen20, compound="left",command=lambda: self.set_borrador_size(30))
        menu.post(150, 100)  # Ubicar el menú desplegable justo debajo del botón


    def create_color_menu(self):
        color_menu = tk.Menu(self.root, tearoff=0,fg="black")
        colors = ['black', 'white', 'red', 'green', 'blue', 'yellow', 'orange', 'pink', 'purple']
        for color in colors:
            color_menu.add_command(label=color, background=color, command=lambda c=color: self.set_color(c))
        color_menu.post(1050, 100)  # Ajusta las coordenadas según tu preferencia

    def update_time(self):
        current_time = time.strftime("%H:%M:%S")
        current_date = time.strftime("%d-%m-%Y")

        self.time_label.config(text=f"Hora: {current_time}")
        self.date_label.config(text=f"Día y Año: {current_date}")

        # Actualizar la hora cada segundo (1000 milisegundos)
        self.root.after(1000, self.update_time)


    def mostrar_ayuda(self):
        self.ventana = ayuida1(self.root)

    def mostrar_atajos(self):
        self.ventana = Atajos(self.root)
    
    def mostrar_version(self):
        self.ventana = version(self.root)


    def set_color(self, color):
        self.selected_color = color



    def eliminar_foto(self, event):
        x, y = event.x, event.y
        # Verificar si el cursor está sobre una imagen importada
        for label, (img_x, img_y) in zip(self.image_labels, self.image_positions):
            img_width = label.winfo_width()
            img_height = label.winfo_height()
            if img_x < x < img_x + img_width and img_y < y < img_y + img_height:
                label.destroy()
                self.parent.image_labels.remove(label)
                break
   
    def set_pincel_size(self, size):
        self.pincel_size = size
        self.select_tool('pincel')

    def set_borrador_size(self, size):
        self.pincel_size = size
        self.select_tool('borrador')

    def select_tool(self, tool):
        self.current_tool = tool
        if tool == 'pincel':
            self.canvas.config(cursor='pencil')
        elif tool == 'texto':
            self.canvas.config(cursor='xterm')
        else:
            self.canvas.config(cursor='arrow')
        print(f"Herramienta seleccionada: {self.current_tool}")

    def select_text_tool(self):
        self.select_tool('texto')

    def create_text_options(self):
        # Crear menú para seleccionar la fuente
        self.font_menu = ttk.Combobox(self.root, textvariable=self.text_font)
        self.font_menu['values'] = ("Arial", "Book Antiqua", "Calibri", "Times New Roman")
        self.font_menu.current(0)

        # Crear menú para seleccionar el tamaño de la fuente
        self.size_menu = ttk.Combobox(self.root, textvariable=self.text_size)
        self.size_menu['values'] = tuple(range(1, 21))
        self.size_menu.current(11)

        # Crear menú para seleccionar el color del texto
        self.color_menu = ttk.Combobox(self.root, textvariable=self.text_color)
        self.color_menu['values'] = ("black", "yellow", "red", "blue")
        self.color_menu.current(0)

    def paint(self, event):
        if self.current_tool == 'pincel':
            if self.last_x and self.last_y:
                self.canvas.create_line(self.last_x, self.last_y, event.x, event.y,
                                        width=self.pincel_size, fill=self.selected_color, capstyle=tk.ROUND, smooth=True)
            self.last_x, self.last_y = event.x, event.y
        elif self.current_tool == 'borrador':
            x, y = event.x, event.y
            if self.last_x and self.last_y:
                items = self.canvas.find_overlapping(self.last_x, self.last_y, x, y)
                for item in items:
                    tags = self.canvas.gettags(item)
                    if "background" not in tags:
                        self.canvas.delete(item)
                self.canvas.create_rectangle(self.last_x, self.last_y, x, y, fill=self.canvas['bg'], outline=self.canvas['bg'], width=self.pincel_size * 8)
                # Verificar si el cursor está sobre una imagen importada y eliminarla si es así
                for label, (img_x, img_y) in zip(self.image_labels, self.image_positions):
                    img_width = label.winfo_width()
                    img_height = label.winfo_height()
                    if img_x < x < img_x + img_width and img_y < y < img_y + img_height:
                        label.destroy()
                        self.image_labels.remove(label)
                        break
            self.last_x, self.last_y = x, y

    def reset_last_pos(self, event):
        self.last_x, self.last_y = None, None

    def start_shape(self, event):
        self.start_x = event.x
        self.start_y = event.y
        self.shape = None



    def draw_shape(self, event):
        if hasattr(self, 'start_x') and hasattr(self, 'start_y'):
            if self.shape:
                self.canvas.delete(self.shape)
            if self.current_tool in ['cuadrado', 'circulo', 'linea', 'triangulo']:
                self.shape = self.create_shape(event.x, event.y, 'white')

    def end_shape(self, event):
        if self.selected_shape_color:
            self.canvas.itemconfig(self.shape, fill=self.selected_shape_color)

    def create_shape(self, x, y, color):
        if self.current_tool == 'cuadrado':
            return self.canvas.create_rectangle(self.start_x, self.start_y, x, y, outline='black', fill=color, tags='shape')
        elif self.current_tool == 'circulo':
            return self.canvas.create_oval(self.start_x, self.start_y, x, y, outline='black', fill=color, tags='shape')
        elif self.current_tool == 'linea':
            return self.canvas.create_line(self.start_x, self.start_y, x, y, fill='black', tags='shape')
        elif self.current_tool == 'triangulo':
            return self.canvas.create_polygon(self.start_x, self.start_y, x, y, self.start_x, y, outline='black', fill=color, tags='shape')


    def handle_click(self, event):
        if self.current_tool == 'texto':
            self.add_text(event)
        else:
            # Si no estamos en la herramienta de texto, mostramos el menú de eliminar imagen
            widget = event.widget
            if isinstance(widget, tk.Label):
                self.display_delete_menu(event)

    def add_text(self, event):
        if self.current_tool == 'texto':
            # Creamos una entrada de texto en la posición del clic
            self.text_entry = tk.Entry(self.root, border=0, width=10)
            self.text_entry.place(x=event.x, y=event.y)
            self.text_entry.config(font=(self.text_font.get(), self.text_size.get()), fg=self.text_color.get())
            self.text_entry.bind('<Return>', self.save_text)
            self.text_entry.bind('<Escape>', self.hide_text_entry)

            # Mostramos los menús de opciones de texto
            self.font_menu.place(x=event.x + 100, y=event.y)
            self.size_menu.place(x=event.x + 250, y=event.y)
            self.color_menu.place(x=event.x + 400, y=event.y)

    def save_text(self, event):
        x = self.text_entry.winfo_x()
        y = self.text_entry.winfo_y()
        text = self.text_entry.get()
        font = (self.text_font.get(), self.text_size.get())
        color = self.text_color.get()
        self.canvas.create_text(x, y, text=text, font=font, fill=color, anchor='nw')
        self.text_entry.destroy()

        # Ocultar los menús después de agregar el texto
        self.font_menu.place_forget()
        self.size_menu.place_forget()
        self.color_menu.place_forget()

    def hide_text_entry(self, event):
        self.text_entry.destroy()
        self.font_menu.place_forget()
        self.size_menu.place_forget()
        self.color_menu.place_forget()

    def open_color_palette(self):
        self.selected_color = colorchooser.askcolor(title="Elige un color")[1]
        if self.selected_color:
            if self.current_tool == 'lienzo':
                self.canvas.config(bg=self.selected_color)
            elif self.current_tool in ['cuadrado', 'circulo', 'linea', 'triangulo']:
                self.selected_shape_color = self.selected_color

    def fill_shape(self, event):
        shape = self.canvas.find_closest(event.x, event.y)
        if shape and self.selected_color:
            self.canvas.itemconfig(shape, fill=self.selected_color)
        

     

    def import_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
        if file_path:
            # Crear campos de entrada para el ancho y alto antes de agregar la imagen
            label_template4= tk.Label(self.root, text="Dimensiones para la imagen", bg='white')
            label_template4.place(x=590, y=5)


            label_template3 = tk.Label(self.root, text="anchor", bg='white')
            label_template3.place(x=570, y=25)
            
            self.width_entry = tk.Entry(self.root,background="white",border=2)
            self.width_entry.place(x=620, y=25, width=50)
            Tooltip(self.width_entry,"Digite el anchor")
            self.width_entry.bind('<KeyRelease>', self.update_image_width)
            
            label_template3 = tk.Label(self.root, text="lado", bg='white')
            label_template3.place(x=675, y=25)
            self.height_entry = tk.Entry(self.root,background="white",border=2)
            self.height_entry.place(x=710, y=25, width=50)
            Tooltip(self.height_entry,"Digite el lado ")
            self.height_entry.bind('<KeyRelease>', self.update_image_height)

            # Cargar la imagen
            image = Image.open(file_path)
            self.image_originals[file_path] = image
            self.current_image_path = file_path
            self.add_image_to_canvas(image)


    def update_image_width(self, event):
        self.update_image_size(event, 'width')

    def update_image_height(self, event):
        self.update_image_size(event, 'height')

    def update_image_size(self, event, dimension):
        file_path = self.current_image_path
        width = int(self.width_entry.get()) if dimension == 'width' else self.image_originals[file_path].width
        height = int(self.height_entry.get()) if dimension == 'height' else self.image_originals[file_path].height

        if self.current_image_path == file_path:
            self.current_image = self.image_originals[file_path].resize((width, height))
            self.update_canvas()

    def update_canvas(self):
        # Limpiar el lienzo antes de agregar la imagen actualizada
        self.canvas.delete(tk.ALL)
        # Convertir la imagen PIL a un objeto de imagen compatible con Tkinter
        photo_image = ImageTk.PhotoImage(self.current_image)
        # Agregar la imagen actualizada al lienzo
        self.canvas.create_image(0, 0, anchor=tk.NW, image=photo_image)
        # Guardar una referencia para evitar que se elimine la imagen
        self.canvas.photo_image = photo_image

    def add_image_to_canvas(self, image):
        image.thumbnail((100, 100))
        photo_image = ImageTk.PhotoImage(image)
        label = tk.Label(self.canvas, image=photo_image)
        label.image = photo_image  # Guardar una referencia para evitar que se elimine
        label.bind('<Button-3>', self.display_delete_menu)  # Vincular el evento de clic derecho para eliminar
        label.place(x=0, y=0)
        self.image_labels.append(label)
        self.image_positions.append((0, 0))
        label.bind('<B1-Motion>', lambda event, label=label: self.drag_image_start(event, label))
        label.bind('<ButtonRelease-1>', lambda event, label=label: self.drag_image_stop(event, label))

    def drag_image_start(self, event, label):
        self.drag_data["item"] = label
        self.drag_data["x"] = event.x
        self.drag_data["y"] = event.y

    def drag_image_stop(self, event, label):
        self.drag_data["item"] = None
        self.drag_data["x"] = 0
        self.drag_data["y"] = 0

    def delete_all_images(self):
        for label in self.image_labels:
            label.destroy()
        self.image_labels = []

    def display_delete_menu(self, event):
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="Eliminar", command=lambda: self.delete_image(event))
        menu.post(event.x_root, event.y_root)

    def delete_image(self, event):
        widget = event.widget
        widget.destroy()
        self.image_labels.remove(widget)

    def export_image(self):
        file_path = filedialog.asksaveasfilename(defaultextension='.png', filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
        if file_path:
            self.save_canvas(file_path)

    def save_canvas(self, file_path):
        # Actualizar el lienzo para asegurarse de que todo el contenido se haya renderizado
        self.canvas.update()
        # Capturar una instantánea del contenido del lienzo como una imagen
        x = self.canvas.winfo_rootx() + self.canvas.winfo_x()
        y = self.canvas.winfo_rooty() + self.canvas.winfo_y()
        width = 1200  # Ancho deseado
        height = 520  # Altura deseada
        ImageGrab.grab().crop((x, y, x + width, y + height)).save(file_path)


    def open_template_window(self):
        root_template = tk.Toplevel()
        plantilla = Plantillas(root_template, self)

    def set_background_image(self, image_path):
        self.background_image = Image.open(image_path)
        self.background_image = self.background_image.resize((1400, 550), Image.LANCZOS)
        self.background_photo = ImageTk.PhotoImage(self.background_image)

        # Eliminar cualquier imagen de fondo existente
        self.canvas.delete("background")

        # Dibujar la nueva imagen de fondo en el lienzo
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.background_photo, tags="background")

        # Mover la imagen de fondo al fondo del lienzo
        self.canvas.tag_lower("background")

    def display_paste_menu(self, event):
        menu = tk.Menu(self.root, tearoff=0)
        menu.add_command(label="Pegar", command=self.paste_from_clipboard)
        menu.post(event.x_root, event.y_root)

    def paste_from_clipboard(self):
        try:
            clipboard_content = pyperclip.paste()  # Obtener el contenido del portapapeles
            if clipboard_content:  # Si hay algo en el portapapeles
                # Pegar el contenido en el lienzo en la posición del cursor
                self.canvas.create_text(self.canvas.canvasx(self.canvas.winfo_pointerx()), 
                                        self.canvas.canvasy(self.canvas.winfo_pointery()), 
                                        text=clipboard_content, font=("Arial", 12), fill="black")
        except Exception as e:
            print("Error al pegar desde el portapapeles:", e)





