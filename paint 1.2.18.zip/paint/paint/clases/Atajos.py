import tkinter as tk

class Atajos:
    def __init__(self, master):
        self.master = master
        self.ventana_emergente = tk.Toplevel(master)
        self.ventana_emergente.title("Atajos")
        self.ventana_emergente.geometry("400x300")
        self.ventana_emergente.resizable(False, False)

        self.frame = tk.Frame(self.ventana_emergente,background="white")
        self.frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        self.imagen100 = tk.PhotoImage(file="paint/imagenes/salida.png")

        atajos = [
            ("<B1-Motion>", "Pintar en la parte blanca"),
            ("<ButtonRelease-1>", "Restablecer última posición"),
            ("<Button-3>", "Iniciar formas (cuadrado, círculo, línea, triángulo)"),
            ("<B3-Motion>", "Dibujar forma"),
            ("<ButtonRelease-3>", "Finalizar forma"),
            ("<Button-2>", "Manipular clic (para empezar a escribir el texto)"),
            ("<Button-1>", "Eliminar imagen (eliminar la imagen importada)"),
            ("<Double-Button-1>", "Mostrar menú paste (pegar texto en el paint)"),
            ("<Double-Button-3>", "Rellenar forma (colocar color a las figuras)"),
        ]

        for atajo, descripcion in atajos:
            tk.Label(self.frame,background="white", text=f"{atajo}: {descripcion}").pack(anchor="w", pady=2,)

        self.boton_cerrar = tk.Button(self.frame, text="Cerrar",image=self.imagen100,border=0,background="white", command=self.cerrar_ventana)
        self.boton_cerrar.pack(pady=10)

    def cerrar_ventana(self):
        self.ventana_emergente.destroy()
