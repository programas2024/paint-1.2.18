import tkinter as tk

class Escritura:
    def __init__(self, canvas):
        self.canvas = canvas
        self.escribiendo = False
        self.texto_entry = None

    def set_canvas(self, canvas):
        self.canvas = canvas

    def get_escribiendo(self):
        return self.escribiendo

    def set_escribiendo(self, estado):
        self.escribiendo = estado

    def get_texto_entry(self):
        return self.texto_entry

    def set_texto_entry(self, entry):
        self.texto_entry = entry

    def habilitar_escritura(self):
        self.escribiendo = True
        self.texto_entry = tk.Entry(self.canvas, bd=2, border=0)  # Crear un Entry
        self.texto_entry.place(x=100, y=100)  # Colocar el Entry en una posición inicial
        self.texto_entry.focus_set()  # Establecer el foco en el Entry
        self.texto_entry.bind("<Return>", self.finalizar_escritura)  # Finalizar la escritura al presionar Enter
        self.texto_entry.bind("<FocusOut>", self.finalizar_escritura)  # Finalizar la escritura al perder el foco

    def finalizar_escritura(self, event=None):
        texto_ingresado = self.texto_entry.get()  # Obtener el texto ingresado
        x = self.texto_entry.winfo_x()  # Obtener la posición x del Entry
        y = self.texto_entry.winfo_y()  # Obtener la posición y del Entry
        self.canvas.create_text(x, y, text=texto_ingresado, font=("Arial", 12), fill="black")  # Crear el texto en el lienzo
        self.texto_entry.destroy()  # Eliminar el Entry
        self.escribiendo = False  # Establecer el estado de escritura a False

    