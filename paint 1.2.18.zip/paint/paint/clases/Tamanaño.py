import tkinter as tk

class Tamaño:
    def __init__(self, root, callback):
        self.root = root
        self.callback = callback
        self.custom_brush_size_frame = None
        self.pincel_size = 1

    def show_custom_brush_size_slider(self):
        if self.custom_brush_size_frame is None:  
            self.custom_brush_size_frame = tk.Frame(self.root, bg="white", width=100, height=58)
            self.custom_brush_size_frame.place(x=930, y=-5)  # Coordenadas ajustadas para el frame
#letra
            slider_label = tk.Label(self.custom_brush_size_frame, text="Tamaño del Pincel:", bg="white")
            slider_label.place(x=0, y=0)
#barra 
            self.brush_size_slider = tk.Scale(self.custom_brush_size_frame, from_=1, to=100, orient="horizontal", command=self.update_pincel_size, background="khaki", border=2, borderwidth=2)
            self.brush_size_slider.set(self.pincel_size)
            self.brush_size_slider.place(x=0, y=20)

    def update_pincel_size(self, value):
        self.pincel_size = int(value)#tamaño pincel 
        self.callback(self.pincel_size)